$(function() {

// $(window).scroll(function() {
// 	var win = $(window).scrollTop();
// 	if(win >= 70){
// 		$("header").css({"background":"#000"});
// 		$(".menu a").css("opacity",1);
// 	}
// 	else{
// 		$("header").css({"background":"transparent"});
// 		$(".menu a").css("opacity",".7");
// 	}
// 	console.log(win)
// })


$("#slider").css("height",$(window).height())

















})